

let bernardo = [
  'girafa',
  'zebra',
  28,
  'analfabeto',
  {
    nome: "Walter",
    age:26,
    isAdm: true
  },
  true
]

console.log(`A quarta linha do seu Array é ${bernardo[4].nome}`)

